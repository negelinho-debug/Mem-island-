extends Node3D

# MEM ISLAND — standalone 3D prototype using meme-inspired character models.
# Character silhouettes created from Godot meshes; not original copyrighted photos/video.
const WALK_SPEED := 8.0
const CHASE_SPEED := 13.0
const JUMP_VELOCITY := 9.2
const GRAVITY := 21.0

var player: CharacterBody3D
var cam: Camera3D
var torch: SpotLight3D
var yaw := PI
var pitch := 0.0
var hearts := 3
var telifons := 0
var got_slipper := false
var cat_spoken := false
var cage_spoken := false
var chase_on := false
var chase_done := false
var fight_on := false
var boss_dead := false
var ending := false
var boss_hp := 10
var boss_time := 0.0
var boss_next_shot := 0.0
var last_attack := -10.0
var last_damage := -10.0
var stage := "СПАВН"
var respawn_at := Vector3(0, 1, -6)
var joystick_touch := -1
var view_touch := -1
var joystick_origin := Vector2.ZERO
var joystick_vector := Vector2.ZERO
var text_expires := 0.0
var enemies: Array[Dictionary] = []
var pickups: Array[Dictionary] = []
var bullets: Array[Dictionary] = []
var boss: Node3D
var boss_parts: Array[MeshInstance3D] = []
var boss_weak := false
var chase_enemy: Node3D
var cat: Node3D
var cage: Node3D
var final_cat: Node3D
var music: AudioStreamPlayer
var hud: Label
var subtitle: Label
var boss_title: Label
var boss_bar: ProgressBar
var credits: PanelContainer
var torch_toggle: Button

func _ready() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	_build_world()
	_build_player()
	_build_ui()
	music = AudioStreamPlayer.new()
	music.stream = load("res://assets/chase_loop.wav")
	if music.stream is AudioStreamWAV:
		(music.stream as AudioStreamWAV).loop_mode = AudioStreamWAV.LOOP_FORWARD
	music.volume_db = -5.0
	add_child(music)
	_show("MEM ISLAND — ДОБРО ПОЖАЛОВАТЬ!", 4.0)

func _mat(color: Color, emissive := false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.84
	if emissive:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = 0.6
	return m

func _visual_box(parent: Node3D, at: Vector3, dims: Vector3, col: Color, rot := Vector3.ZERO) -> MeshInstance3D:
	var obj := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = dims
	obj.mesh = mesh
	obj.material_override = _mat(col)
	obj.position = at
	obj.rotation = rot
	parent.add_child(obj)
	return obj

func _ground(label: String, at: Vector3, dims: Vector3, col: Color) -> void:
	var body := StaticBody3D.new()
	body.name = label
	body.position = at
	add_child(body)
	_visual_box(body, Vector3.ZERO, dims, col)
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = dims
	shape.shape = box
	body.add_child(shape)

func _orb(parent: Node3D, at: Vector3, scale: Vector3, col: Color, glowing := false) -> MeshInstance3D:
	var obj := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	mesh.radial_segments = 12
	mesh.rings = 7
	obj.mesh = mesh
	obj.position = at
	obj.scale = scale
	obj.material_override = _mat(col, glowing)
	parent.add_child(obj)
	return obj

func _sign(parent: Node3D, words: String, at: Vector3, col := Color.WHITE) -> void:
	var lbl := Label3D.new()
	lbl.text = words
	lbl.position = at
	lbl.font_size = 36
	lbl.pixel_size = 0.008
	lbl.modulate = col
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.no_depth_test = true
	parent.add_child(lbl)

func _pine(x: float, z: float, h := 5.0) -> void:
	var tree := Node3D.new()
	tree.position = Vector3(x, 0.0, z)
	add_child(tree)
	var trunk := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.21
	cyl.bottom_radius = 0.32
	cyl.height = h * 0.45
	trunk.mesh = cyl
	trunk.position.y = h * 0.23
	trunk.material_override = _mat(Color(0.31, 0.20, 0.13))
	tree.add_child(trunk)
	var leaves := MeshInstance3D.new()
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = h * 0.30
	cone.height = h * 0.82
	leaves.mesh = cone
	leaves.position.y = h * 0.67
	leaves.material_override = _mat(Color(0.10, 0.28, 0.25))
	tree.add_child(leaves)

func _lamp(x: float, z: float) -> void:
	_visual_box(self, Vector3(x, 2.0, z), Vector3(0.22, 4.0, 0.22), Color(0.15, 0.16, 0.21))
	_orb(self, Vector3(x, 4.0, z), Vector3(0.6, 0.6, 0.6), Color(1.0, 0.83, 0.41), true)
	var light := OmniLight3D.new()
	light.position = Vector3(x, 4, z)
	light.light_color = Color(1, 0.73, 0.43)
	light.light_energy = 1.8
	light.omni_range = 13
	add_child(light)

func _build_world() -> void:
	var env := WorldEnvironment.new()
	var settings := Environment.new()
	settings.background_mode = Environment.BG_COLOR
	settings.background_color = Color(0.025, 0.038, 0.09)
	settings.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	settings.ambient_light_color = Color(0.36, 0.42, 0.53)
	settings.ambient_light_energy = 0.75
	settings.fog_enabled = true
	settings.fog_light_color = Color(0.055, 0.09, 0.15)
	settings.fog_density = 0.009
	env.environment = settings
	add_child(env)
	var moon := DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-55, 35, 0)
	moon.light_color = Color(0.5, 0.68, 1)
	moon.light_energy = 0.55
	add_child(moon)
	_ground("МОРЕ", Vector3(0, -9, 140), Vector3(400, 1, 620), Color(0.02, 0.11, 0.19))
	_ground("Стартовый остров", Vector3(0, -0.6, 10), Vector3(43, 1.2, 56), Color(0.13, 0.27, 0.21))
	# Road runs directly after the short forest.
	_ground("Дорога погони", Vector3(0, -0.45, 66), Vector3(18, 0.9, 65), Color(0.20, 0.23, 0.29))
	for i in range(14):
		_visual_box(self, Vector3(0, 0.018, 38.0 + i * 4.4), Vector3(0.18, 0.03, 1.9), Color(0.87, 0.87, 0.79))
	for i in range(6):
		var z := 99.0 + i * 9.3
		var y := i * 0.45
		_ground("Ледяная тропа %d" % i, Vector3(0, y - 0.40, z), Vector3(19, 0.8, 9.4), Color(0.48, 0.77, 0.91))
		_visual_box(self, Vector3(-12 if i % 2 == 0 else 12, y + 1.8, z), Vector3(6, 5, 6), Color(0.52, 0.82, 0.96))
	_ground("Подход к паркуру", Vector3(0, 2.6, 151.9), Vector3(11, 0.9, 7.5), Color(0.51, 0.73, 0.87))
	for i in range(7):
		var z := 161.0 + i * 8.5
		var x := float((i % 3) - 1) * 2.1
		_ground("Паркур %d" % i, Vector3(x, 2.5, z), Vector3(7.8, 1, 5.6), Color(0.44, 0.37, 0.67))
		_visual_box(self, Vector3(x, 3.02, z - 2.68), Vector3(7.8, 0.08, 0.18), Color(0.28, 0.83, 0.97))
	_ground("Мост к арене", Vector3(0, 0, 214.0), Vector3(12, 2, 13), Color(0.17, 0.28, 0.25))
	_ground("Арена Воздухана", Vector3(0, -0.85, 236), Vector3(46, 1.7, 47), Color(0.22, 0.23, 0.32))
	for i in range(12):
		var angle := i * TAU / 12.0
		_visual_box(self, Vector3(sin(angle)*21, 2, 236+cos(angle)*21), Vector3(1.6, 4, 1.6), Color(0.12, 0.15, 0.2))
	_ground("Остров концовки", Vector3(0, -0.5, 285), Vector3(37, 1, 32), Color(0.15, 0.34, 0.25))
	for i in range(14):
		var z := -9.0 + i * 3.45
		_pine(-12.0 - (i % 3)*2, z, 5.5)
		_pine(12.0 + (i % 3)*1.5, z + 0.5, 5.2)
	for i in range(8):
		var z := 14.0 + i * 2.8
		_pine(-8.5 - (i % 2) * 2.5, z, 5)
		_pine(8.5 + (i % 2) * 2.5, z + 1.5, 5.2)
	for i in range(7):
		_lamp(-8.5 if i % 2 == 0 else 8.5, 38 + i * 8.5)
	_lamp(-7, 1)
	_lamp(7, 15)
	_lamp(3, 281)
	_make_cat(Vector3(-4, 0, 3), false)
	_make_cage(Vector3(7, 0, 6))
	_make_cat(Vector3(0, 0, 286), true)
	_make_meme_enemies()
	_make_pickups()
	_make_boss()

func _make_cat(pos: Vector3, is_final: bool) -> void:
    var root := Node3D.new()
    root.name = "КОТОСТЬ — финал" if is_final else "КОТОСТЬ — лавка"
    root.position = pos
    add_child(root)
    if not is_final:
        _visual_box(self, Vector3(-4, 0.7, 1.7), Vector3(7, 1.4, 4), Color(0.46, 0.25, 0.17))
        _visual_box(self, Vector3(-4, 3.5, 1.7), Vector3(8.5, 0.55, 5), Color(0.4, 0.17, 0.22))
        for side in [-1, 1]:
            _visual_box(self, Vector3(-4 + side*3.1, 2.0, 3.4), Vector3(0.25, 3.5, 0.25), Color(0.36, 0.2, 0.15))
    _cat_model(root)
    _sign(root, "КОТОСТЬ", Vector3(0, 3.75, 0), Color(1,.88,.46))
    if is_final:
        final_cat = root
    else:
        cat = root

func _make_cage(pos: Vector3) -> void:
    cage = Node3D.new()
    cage.name = "Мелстрой в клетке"
    cage.position = pos
    add_child(cage)
    for y in [0.1, 3.0]:
        _visual_box(cage, Vector3(0, y, 0), Vector3(4, 0.2, 4), Color(0.54, 0.6, 0.64))
    for i in range(-2, 3):
        for a in [-1.9, 1.9]:
            _visual_box(cage, Vector3(i*0.85, 1.5, a), Vector3(0.12, 3, 0.12), Color(0.57, 0.6, 0.66))
            _visual_box(cage, Vector3(a, 1.5, i*0.85), Vector3(0.12, 3, 0.12), Color(0.57, 0.6, 0.66))
    _mellstroy_model(cage)
    _sign(cage, "МЕЛСТРОЙ", Vector3(0, 3.9, 0))

# Distinct handmade 3D meme-inspired character silhouettes.
# No scraped photos, copied video textures or third-party audio are included.
func _limb(root: Node3D, start: Vector3, finish: Vector3, radius: float, col: Color) -> void:
    var direction: Vector3 = finish - start
    var seg := MeshInstance3D.new()
    var cylinder := CylinderMesh.new()
    cylinder.top_radius = radius
    cylinder.bottom_radius = radius
    cylinder.height = direction.length()
    cylinder.radial_segments = 8
    seg.mesh = cylinder
    seg.position = (start + finish) * 0.5
    seg.quaternion = Quaternion(Vector3.UP, direction.normalized())
    seg.material_override = _mat(col)
    root.add_child(seg)

func _ears(root: Node3D, y: float, length: float, color: Color, inner: Color) -> void:
    for side in [-1, 1]:
        _orb(root, Vector3(side*0.46, y+length*0.38, 0.05), Vector3(0.39, length, 0.30), color)
        _orb(root, Vector3(side*0.46, y+length*0.42, -0.11), Vector3(0.19, length*0.65, 0.10), inner)

func _face(root: Node3D, y: float, z: float, gap: float, pupil: Color = Color(0.05,0.06,0.08)) -> void:
    for side in [-1, 1]:
        _orb(root, Vector3(side*gap, y, z), Vector3(0.31, 0.34, 0.17), Color.WHITE)
        _orb(root, Vector3(side*gap-0.04, y, z-0.12), Vector3(0.12,0.15,0.08), pupil)
        _orb(root, Vector3(side*gap-0.065, y+0.075, z-0.172), Vector3(0.042,0.048,0.026), Color.WHITE)

func _whiskers(root: Node3D, y: float, z: float) -> void:
    for side in [-1, 1]:
        for index in range(3):
            _limb(root, Vector3(side*0.32,y,z),Vector3(side*0.94,y+(index-1)*0.12,z-0.04),0.013,Color(0.2,0.18,0.18))

func _cat_model(root: Node3D) -> void:
    # Kuki / Kotost-inspired extremely fat calico cat, not a colored ball.
    var cream := Color(0.98,0.91,0.77)
    var orange := Color(0.86,0.45,0.14)
    var ink := Color(0.18,0.17,0.20)
    _orb(root, Vector3(0,0.92,0.20), Vector3(2.65,1.75,1.9), cream)
    _orb(root, Vector3(-0.75,1.05,-0.42),Vector3(1.18,1.20,0.65),orange)
    _orb(root, Vector3(0.72,1.20,0.10),Vector3(1.0,1.26,1.48),ink)
    _orb(root, Vector3(0,1.95,0.03),Vector3(1.7,1.55,1.5),cream)
    _orb(root, Vector3(-0.47,2.21,-0.40),Vector3(0.91,0.87,0.44),orange)
    _orb(root, Vector3(0.53,2.37,-0.32),Vector3(0.83,0.78,0.44),ink)
    _ears(root, 2.70, 0.8, ink, Color(0.86,0.55,0.6))
    _face(root, 2.02,-0.74,0.40,Color(0.09,0.13,0.08))
    _orb(root,Vector3(0,1.68,-0.80),Vector3(.23,.14,.12),Color(.93,.48,.56))
    _whiskers(root,1.66,-0.76)
    for x in [-0.74,0.74]:
        _orb(root,Vector3(x,0.23,-0.47),Vector3(0.59,0.43,0.88),cream)

func _model_cheremsha(root: Node3D) -> void:
    var fur := Color(0.85,0.80,0.68)
    var mane := Color(0.61,0.40,0.21)
    _orb(root,Vector3(0,-0.21,0.17),Vector3(1.08,1.30,1.7),fur)
    for x in [-0.33,0.33]:
        _orb(root,Vector3(x,-0.90,-0.43),Vector3(.38,.5,.64),fur)
    _orb(root,Vector3(0,0.58,0),Vector3(1.65,1.58,1.21),mane)
    _orb(root,Vector3(0,0.63,-0.39),Vector3(1.24,1.16,1.08),fur)
    _ears(root,1.23,1.55,fur,Color(.82,.54,.56))
    _face(root,0.77,-0.95,.30)
    _orb(root,Vector3(0,0.38,-1.02),Vector3(.43,.35,.28),Color(.94,.87,.73))
    _orb(root,Vector3(0,0.50,-1.28),Vector3(.17,.13,.11),Color(.23,.16,.14))

func _model_semga(root: Node3D) -> void:
    # Sëмга in Cheremsha meme lore: a tiger-faced rabbit.
    var orange := Color(.98,.60,.18)
    var tiger := Color(.16,.11,.09)
    _orb(root,Vector3(0,-.25,0),Vector3(1.08,1.34,1.45),Color(.82,.68,.48))
    _orb(root,Vector3(0,.50,-.22),Vector3(1.34,1.25,1.20),orange)
    _ears(root,1.1,1.33,orange,Color(.65,.32,.24))
    _face(root,.63,-.80,.34,Color(.08,.14,.07))
    _orb(root,Vector3(0,.30,-.93),Vector3(.33,.25,.23),Color(.96,.91,.79))
    _orb(root,Vector3(0,.37,-1.15),Vector3(.14,.1,.08),tiger)
    for side in [-1,1]:
        for i in range(3):
            var slash := _visual_box(root, Vector3(side*(.56+i*.13),.9-i*.31,-.55),Vector3(.07,.34,.14),tiger)
            slash.rotation.z = side*0.35

func _model_brdysch(root: Node3D) -> void:
    # Брдыщ: fish body with a dog's snout.
    var body := Color(.62,.79,.84)
    var fin := Color(.35,.52,.67)
    _orb(root,Vector3(0,-.05,.18),Vector3(1.3,.88,2.20),body)
    _orb(root,Vector3(0,.25,-.61),Vector3(1.07,.86,1.04),Color(.71,.47,.29))
    _orb(root,Vector3(0,-.02,-1.16),Vector3(.64,.43,.73),Color(.81,.60,.39))
    _orb(root,Vector3(0,.10,-1.53),Vector3(.23,.15,.20),Color(.15,.12,.12))
    _orb(root,Vector3(-.72,.48,-.38),Vector3(.5,.82,.31),Color(.48,.32,.19))
    _orb(root,Vector3(.72,.48,-.38),Vector3(.5,.82,.31),Color(.48,.32,.19))
    _face(root,.44,-1.04,.30)
    _visual_box(root,Vector3(0,.62,.6),Vector3(.21,.66,.66),fin)
    _visual_box(root,Vector3(0,0,1.33),Vector3(1.3,.16,.85),fin,Vector3(0,0,.35))

func _model_burmalda(root: Node3D) -> void:
    # Dog-like figure in the fictional Soviet Cheremsha universe.
    var coat := Color(.57,.36,.19)
    var ear := Color(.30,.20,.13)
    _orb(root,Vector3(0,-.19,.20),Vector3(1.40,1.34,1.85),coat)
    _orb(root,Vector3(0,.63,-.34),Vector3(1.28,1.13,1.15),coat)
    for side in [-1,1]:
        _orb(root,Vector3(side*.70,.61,-.18),Vector3(.41,.88,.39),ear)
        _orb(root,Vector3(side*.46,-.90,-.4),Vector3(.4,.60,.58),coat)
    _face(root,.78,-.91,.32)
    _orb(root,Vector3(0,.28,-1),Vector3(.76,.50,.69),Color(.78,.57,.32))
    _orb(root,Vector3(0,.34,-1.36),Vector3(.27,.19,.21),ear)

func _model_mouse(root: Node3D) -> void:
    var grey := Color(.56,.54,.59)
    var pink := Color(.89,.51,.64)
    _orb(root,Vector3(0,-.28,.2),Vector3(1.11,1.25,1.2),grey)
    _orb(root,Vector3(0,.57,-.26),Vector3(1.40,1.23,1.13),grey)
    for side in [-1,1]:
        _orb(root,Vector3(side*.80,1.30,-.18),Vector3(.91,.95,.35),grey)
        _orb(root,Vector3(side*.80,1.30,-.39),Vector3(.63,.70,.19),pink)
    _face(root,.64,-.87,.36)
    _orb(root,Vector3(0,.15,-1.10),Vector3(.31,.29,.3),pink)
    _whiskers(root,.17,-1.04)
    _limb(root,Vector3(0,-.7,.57),Vector3(.72,-.45,1.20),.09,pink)
    _limb(root,Vector3(.72,-.45,1.20),Vector3(1.0,.0,1.42),.08,pink)

func _model_plaksik(root: Node3D) -> void:
    var blue := Color(.25,.67,.96)
    _orb(root,Vector3(0,-.12,0),Vector3(1.45,1.61,1.18),blue)
    _orb(root,Vector3(0,.77,.1),Vector3(.84,.83,.92),blue)
    _face(root,.34,-.62,.36)
    _orb(root,Vector3(0,-.24,-.69),Vector3(.37,.47,.14),Color(.09,.17,.27))
    for side in [-1,1]:
        _orb(root,Vector3(side*.41,.00,-.79),Vector3(.11,.61,.08),Color(.61,.91,1),true)
        _orb(root,Vector3(side*.44,-.52,-.79),Vector3(.24,.29,.12),Color(.61,.91,1),true)

func _model_puhosos(root: Node3D) -> void:
    # A little cotton-fluff vacuum robot, not a fantasy purple blob.
    _visual_box(root,Vector3(0,-.16,.05),Vector3(1.35,1.26,1.6),Color(.88,.79,.42))
    _visual_box(root,Vector3(0,.58,.0),Vector3(1.00,.33,1.2),Color(.47,.48,.53))
    for side in [-1,1]:
        _orb(root,Vector3(side*.73,-.58,.3),Vector3(.36,.73,.73),Color(.16,.19,.22))
    _orb(root,Vector3(0,-.11,-.92),Vector3(.80,.69,.32),Color(.26,.26,.30))
    _orb(root,Vector3(0,-.11,-1.08),Vector3(.60,.49,.15),Color(.08,.08,.09))
    _face(root,.70,-.65,.27)
    for i in range(8):
        var a := i*TAU/8
        _orb(root,Vector3(cos(a)*.86,1.25,sin(a)*.65),Vector3(.23,.24,.23),Color(.95,.96,.95))

func _model_six_seven(root: Node3D) -> void:
    _visual_box(root,Vector3(0,-.28,.10),Vector3(1.68,1.5,.72),Color(.43,.28,.72))
    for digit in range(2):
        var txt := Label3D.new()
        txt.text = "6" if digit == 0 else "7"
        txt.font_size = 190
        txt.pixel_size = 0.012
        txt.position = Vector3(-.50 if digit == 0 else .46,.1,-.46)
        txt.modulate = Color(1,.94,.18)
        root.add_child(txt)
    _orb(root,Vector3(-.36,-1.13,.0),Vector3(.37,.54,.42),Color(.4,.2,.65))
    _orb(root,Vector3(.36,-1.13,.0),Vector3(.37,.54,.42),Color(.4,.2,.65))

func _mellstroy_model(root: Node3D) -> void:
    # Stylized human figure; exact likeness requires a licensed reference.
    _orb(root,Vector3(0,1.0,0),Vector3(1.03,1.44,.72),Color(.82,.16,.14))
    _orb(root,Vector3(0,2.13,-.09),Vector3(.86,.96,.78),Color(.93,.68,.51))
    _orb(root,Vector3(0,2.60,-.03),Vector3(.93,.40,.78),Color(.22,.13,.11))
    _face(root,2.21,-.46,.21)
    _orb(root,Vector3(0,1.89,-.50),Vector3(.32,.12,.06),Color(.40,.18,.15))
    for side in [-1,1]:
        _limb(root,Vector3(side*.48,1.37,0),Vector3(side*.76,.49,-.12),.18,Color(.93,.68,.51))

func _boss_wind_details(root: Node3D) -> void:
    # Wind vortex around the boss — distinguishable from an ordinary blue orb.
    for i in range(4):
        var ring := MeshInstance3D.new()
        var mesh := TorusMesh.new()
        mesh.inner_radius = 1.35 + i*.12
        mesh.outer_radius = 1.52 + i*.12
        ring.mesh = mesh
        ring.position = Vector3(0,-1.30+i*.71,0)
        ring.rotation = Vector3(.23,0,.30)
        ring.material_override = _mat(Color(.45+i*.08,.83,1),true)
        root.add_child(ring)
    for side in [-1,1]:
        _orb(root,Vector3(side*.63,.36,-1.35),Vector3(.35,.44,.18),Color(.07,.17,.27))
        _orb(root,Vector3(side*.68,.44,-1.50),Vector3(.10,.12,.07),Color.WHITE)
    _orb(root,Vector3(0,-.25,-1.40),Vector3(.67,.20,.13),Color(.10,.17,.23))

func _make_enemy(title: String, pos: Vector3, color: Color, speed: float) -> void:
    var root := Node3D.new()
    root.name = title
    root.position = pos
    add_child(root)
    match title:
        "6-7": _model_six_seven(root)
        "ЧЕРЕМША": _model_cheremsha(root)
        "БУРМАЛДА": _model_burmalda(root)
        "СЕМГА": _model_semga(root)
        "БРДЫЩ": _model_brdysch(root)
        "ПУХОСОС": _model_puhosos(root)
        "МЫШЬ ПОЗОРА": _model_mouse(root)
        "ПЛАКСИК": _model_plaksik(root)
        _: _orb(root, Vector3.ZERO, Vector3(1.35,1.55,1.2), color)
    _sign(root, title, Vector3(0, 2.5, 0), Color(1,0.92,0.68))
    enemies.append({"node": root, "home": pos, "speed": speed, "dead": false, "next": 0.0, "hp": 2})

func _make_meme_enemies() -> void:
	_make_enemy("6-7", Vector3(5, 1.1, 27), Color(0.85, 0.22, 0.78), 3.3)
	_make_enemy("ЧЕРЕМША", Vector3(-5, 1.1, 20), Color(0.66, 0.76, 0.20), 2.7)
	_make_enemy("БУРМАЛДА", Vector3(6, 1.1, 73), Color(0.92, 0.45, 0.16), 3.0)
	_make_enemy("ПЛАКСИК", Vector3(-5, 3.2, 119), Color(0.27, 0.77, 0.97), 2.1)
	_make_enemy("МЫШЬ ПОЗОРА", Vector3(4, 3.4, 140), Color(0.58, 0.55, 0.65), 3.2)
	_make_enemy("СЕМГА", Vector3(-4, 3.0, 149), Color(0.93, 0.52, 0.37), 2.4)
	_make_enemy("ПУХОСОС", Vector3(0, 4.1, 184), Color(0.73, 0.66, 0.98), 2.1)
	_make_enemy("БРДЫЩ", Vector3(-6, 1.1, 232), Color(0.65, 0.30, 0.34), 2.4)
	var ice := Node3D.new()
	ice.position = Vector3(-5.5, 5, 131)
	ice.name = "ЛУК ЧЕСНОК (кубик льда с глазами)"
	add_child(ice)
	var ice_body := _visual_box(ice, Vector3.ZERO, Vector3(2.5, 2.5, 2.5), Color(0.55, 0.86, 0.98))
	var ice_material := _mat(Color(0.57, 0.89, 1.0, 0.87))
	ice_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ice_material.roughness = 0.13
	ice_body.material_override = ice_material
	_visual_box(ice, Vector3(.42,.8,-1.27), Vector3(.55,.14,.07), Color(.91,.99,1.0))
	for x in [-0.53, 0.53]:
		_orb(ice, Vector3(x, 0.33, -1.28), Vector3(0.47, 0.47, 0.24), Color.WHITE)
		_orb(ice, Vector3(x, 0.33, -1.43), Vector3(0.19, 0.19, 0.10), Color(0.07, 0.09, 0.13))
	_sign(ice, "ЛУК ЧЕСНОК", Vector3(0, 2.1, 0), Color.CYAN)

func _create_telifon(pos: Vector3, number: int) -> void:
	var root := Node3D.new()
	root.name = "ТЕЛИФОН %d" % number
	root.position = pos
	add_child(root)
	_orb(root, Vector3.ZERO, Vector3(1, 0.67, 1.1), Color(0.23, 0.83, 0.84), true)
	for x in [-0.21, 0.21]:
		_orb(root, Vector3(x, 0.29, -0.5), Vector3(0.22, 0.22, 0.13), Color.WHITE)
		_orb(root, Vector3(x, 0.29, -0.6), Vector3(0.1, 0.1, 0.09), Color(0.04, 0.07, 0.1))
	for side in [-1, 1]:
		for j in range(4):
			_visual_box(root, Vector3(side * (0.59 + j*0.045), -0.12, (float(j)-1.5)*0.25), Vector3(0.7, 0.11, 0.1), Color(0.12, 0.61, 0.67), Vector3(0, (j-1.5)*0.13, side*0.3))
	_sign(root, "ТЕЛИФОН", Vector3(0, 1.16, 0), Color(0.45, 0.98, 1))
	pickups.append({"node": root, "taken": false, "number": number, "home": pos})

func _make_pickups() -> void:
	var spots := [
		Vector3(8, 1.0, 4), Vector3(11, 1.0, 14), Vector3(-10, 1, 20), Vector3(-8, 1, 29),
		Vector3(6, 1, 43), Vector3(-5, 1, 57), Vector3(5, 1, 74), Vector3(-6, 1, 89),
		Vector3(5, 1.2, 102), Vector3(-4, 2.2, 115), Vector3(4, 3, 133), Vector3(-5, 3.5, 146),
		Vector3(-2, 3.4, 160), Vector3(-2, 3.3, 187)
	]
	for i in range(spots.size()):
		_create_telifon(spots[i], i+1)

func _make_boss() -> void:
	boss = Node3D.new()
	boss.name = "ВОЗДУХАН — финальный босс"
	boss.position = Vector3(0, 5, 236)
	add_child(boss)
	boss_parts.append(_orb(boss, Vector3.ZERO, Vector3(3.2, 2.6, 2.5), Color(0.3, 0.68, 0.94)))
	boss_parts.append(_orb(boss, Vector3(-1.3, 0.4, 0), Vector3(2.2, 2.2, 2.2), Color(0.3, 0.68, 0.94)))
	boss_parts.append(_orb(boss, Vector3(1.3, 0.4, 0), Vector3(2.2, 2.2, 2.2), Color(0.3, 0.68, 0.94)))
	for x in [-0.62, 0.62]:
		_orb(boss, Vector3(x, 0.35, -1.28), Vector3(0.34, 0.35, 0.2), Color(0.05, 0.06, 0.09))
	_boss_wind_details(boss)
	_sign(boss, "ВОЗДУХАН", Vector3(0, 3.1, 0))

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Игрок"
	player.position = respawn_at
	player.rotation.y = yaw
	player.floor_snap_length = 0.25
	add_child(player)
	var collider := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.37
	shape.height = 1.8
	collider.shape = shape
	collider.position.y = 0.9
	player.add_child(collider)
	cam = Camera3D.new()
	cam.position.y = 1.6
	cam.fov = 73
	cam.current = true
	player.add_child(cam)
	torch = SpotLight3D.new()
	torch.light_energy = 4
	torch.spot_range = 27
	torch.spot_angle = 56
	torch.light_color = Color(0.95, 0.96, 1)
	cam.add_child(torch)

func _hud_label(text: String, x: float, y: float, size: int = 27) -> Label:
	var l := Label.new()
	l.text = text
	l.position = Vector2(x, y)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_color_override("font_shadow_color", Color.BLACK)
	l.add_theme_constant_override("shadow_offset_x", 2)
	l.add_theme_constant_override("shadow_offset_y", 2)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _button(text: String, left: int, bottom: int, width: int, callback: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.anchor_left = 1.0
	b.anchor_right = 1.0
	b.anchor_top = 1.0
	b.anchor_bottom = 1.0
	b.offset_left = left
	b.offset_right = left + width
	b.offset_top = bottom
	b.offset_bottom = bottom + 64
	b.add_theme_font_size_override("font_size", 22)
	b.pressed.connect(callback)
	return b

func _build_ui() -> void:
	var canvas := CanvasLayer.new()
	canvas.layer = 5
	add_child(canvas)
	var screen := Control.new()
	screen.set_anchors_preset(Control.PRESET_FULL_RECT)
	screen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	canvas.add_child(screen)
	hud = _hud_label("", 24, 18, 28)
	screen.add_child(hud)
	subtitle = _hud_label("", 0, 0, 24)
	subtitle.anchor_left = 0.12
	subtitle.anchor_right = 0.88
	subtitle.anchor_top = 0.72
	subtitle.anchor_bottom = 0.72
	subtitle.offset_left = 0
	subtitle.offset_right = 0
	subtitle.offset_top = 0
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	screen.add_child(subtitle)
	var cross := _hud_label("+", 0, 0, 30)
	cross.set_anchors_preset(Control.PRESET_CENTER)
	cross.offset_left = -8
	cross.offset_top = -22
	screen.add_child(cross)
	boss_title = _hud_label("ВОЗДУХАН", 0, 75, 28)
	boss_title.anchor_left = 0.3
	boss_title.anchor_right = 0.7
	boss_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	boss_title.visible = false
	screen.add_child(boss_title)
	boss_bar = ProgressBar.new()
	boss_bar.anchor_left = 0.25
	boss_bar.anchor_right = 0.75
	boss_bar.offset_top = 122
	boss_bar.offset_bottom = 149
	boss_bar.max_value = 10
	boss_bar.value = 10
	boss_bar.show_percentage = false
	boss_bar.visible = false
	boss_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen.add_child(boss_bar)
	screen.add_child(_button("УДАР 🩴", -168, -96, 149, _attack))
	screen.add_child(_button("ПРЫЖОК", -340, -96, 158, _jump))
	screen.add_child(_button("ГОВОРИТЬ", -213, -175, 193, _interact))
	torch_toggle = _button("🔦", -91, -251, 70, _toggle_torch)
	screen.add_child(torch_toggle)
	var instructions := _hud_label("Левый низ: движение     Правый экран: обзор\nПК: WASD, мышь, ПРОБЕЛ, F, E", 23, 0, 18)
	instructions.anchor_top = 1.0
	instructions.anchor_bottom = 1.0
	instructions.offset_top = -75
	screen.add_child(instructions)
	credits = PanelContainer.new()
	credits.anchor_left = 0.18
	credits.anchor_top = 0.22
	credits.anchor_right = 0.82
	credits.anchor_bottom = 0.78
	credits.visible = false
	credits.mouse_filter = Control.MOUSE_FILTER_STOP
	screen.add_child(credits)
	var endtext := Label.new()
	endtext.text = "MEM ISLAND\n\nTHE END\n\nВсе 15 Телифонов найдены!\nВоздухан побеждён... но обещал вернуться.\n\nСпасибо за игру!\nСоздатель: Negelinho\nПродолжение следует?.."
	endtext.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	endtext.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	endtext.add_theme_font_size_override("font_size", 24)
	credits.add_child(endtext)

func _show(line: String, duration := 4.0) -> void:
	if subtitle != null:
		subtitle.text = line
	text_expires = Time.get_ticks_msec() / 1000.0 + duration

func _toggle_torch() -> void:
	torch.visible = not torch.visible

func _jump() -> void:
	if player.is_on_floor():
		player.velocity.y = JUMP_VELOCITY

func _interact() -> void:
	if ending:
		return
	if player.position.distance_to(cat.position) < 6.0:
		if not cat_spoken:
			cat_spoken = true
			got_slipper = true
			_show("КОТОСТЬ: Собери 15 Телифонов! Тут полно ненормальных мемов. А, точно! Тебе оружие нужно. Всё, что есть — этот тапок. Ладно, иди!", 12)
		else:
			_show("КОТОСТЬ: Ты опять сюда? Я вообще-то отдыхаю!", 5)
	elif player.position.distance_to(cage.position) < 5.5:
		cage_spoken = true
		_show("МЕЛСТРОЙ: Здаров! Меня поймал Интерпол, но меня скоро заберут птенцы!", 9)
	elif player.position.distance_to(final_cat.position) < 6.0 and telifons == 15:
		_finish()
	else:
		_show("Здесь не с кем говорить. Ищи Телифонов!", 2.5)

func _attack() -> void:
	var now := Time.get_ticks_msec() / 1000.0
	if now - last_attack < 0.52:
		return
	last_attack = now
	if not got_slipper:
		_show("Сначала возьми тапок у Котости!", 2.5)
		return
	_show("ШЛЁП!", 0.35)
	var aim := -player.global_transform.basis.z
	if fight_on and not boss_dead and boss_weak:
		var toward := boss.global_position - player.global_position
		toward.y = 0
		if toward.length() < 5.2 and toward.normalized().dot(aim) > 0.15:
			boss_hp -= 1
			boss_bar.value = boss_hp
			if boss_hp == 5:
				_show("ВОЗДУХАН: ТЫ МЕНЯ БЕСИШЬ!!! — СУПЕРФОРМА!", 6)
				for p in boss_parts:
					p.material_override = _mat(Color(1.0, 0.31, 0.22), true)
				boss.scale = Vector3.ONE * 1.25
			elif boss_hp <= 0:
				_win_boss()
			return
	for enemy in enemies:
		if enemy["dead"]:
			continue
		var node: Node3D = enemy["node"]
		var toward := node.global_position - player.global_position
		toward.y = 0
		if toward.length() < 3.4 and toward.normalized().dot(aim) > 0.1:
			enemy["hp"] -= 1
			if enemy["hp"] <= 0:
				enemy["dead"] = true
				node.queue_free()
			return

func _get_hit() -> void:
	var now := Time.get_ticks_msec() / 1000.0
	if now - last_damage < 1.35 or ending:
		return
	last_damage = now
	hearts -= 1
	_show("АЙ! -1 СЕРДЕЧКО", 2)
	if hearts <= 0:
		hearts = 3
		player.global_position = respawn_at
		player.velocity = Vector3.ZERO
		_show("Ты проиграл! Возрождение у контрольной точки (собранное сохранилось).", 5)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < get_viewport().get_visible_rect().size.x * 0.47 and event.position.y > get_viewport().get_visible_rect().size.y * 0.45 and joystick_touch == -1:
				joystick_touch = event.index
				joystick_origin = event.position
				joystick_vector = Vector2.ZERO
			elif view_touch == -1:
				view_touch = event.index
		else:
			if event.index == joystick_touch:
				joystick_touch = -1
				joystick_vector = Vector2.ZERO
			if event.index == view_touch:
				view_touch = -1
	elif event is InputEventScreenDrag:
		if event.index == joystick_touch:
			joystick_vector = ((event.position - joystick_origin) / 92).limit_length()
		elif event.index == view_touch:
			_look(event.relative)
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		_look(event.relative)
	elif event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_F: _attack()
			KEY_E: _interact()
			KEY_SPACE: _jump()
			KEY_L: _toggle_torch()

func _look(relative: Vector2) -> void:
	yaw -= relative.x * 0.004
	pitch = clampf(pitch - relative.y * 0.004, -1.3, 1.3)
	player.rotation.y = yaw
	cam.rotation.x = pitch

func _physics_process(delta: float) -> void:
	var dir2 := joystick_vector
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): dir2.y -= 1
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): dir2.y += 1
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): dir2.x -= 1
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): dir2.x += 1
	dir2 = dir2.limit_length(1)
	var direction := player.global_transform.basis.x * dir2.x + player.global_transform.basis.z * dir2.y
	var speed := CHASE_SPEED if chase_on else WALK_SPEED
	player.velocity.x = direction.x * speed
	player.velocity.z = direction.z * speed
	if not player.is_on_floor():
		player.velocity.y -= GRAVITY * delta
	player.move_and_slide()
	if player.global_position.y < -12:
		player.global_position = respawn_at
		player.velocity = Vector3.ZERO
		_get_hit()
	_check_route()
	_update_pickups(delta)
	_update_enemies(delta)
	_update_chase(delta)
	_update_boss(delta)
	_update_bullets(delta)
	_update_hud()

func _check_route() -> void:
	var z := player.global_position.z
	if z > 15 and z < 39:
		stage = "ЛЕС"
	elif z >= 39 and z < 98:
		stage = "ДОРОГА"
		if not chase_done and not chase_on:
			_begin_chase()
	elif z >= 98 and z < 155:
		stage = "ЛЕДЯНАЯ ГОРА"
		if chase_on:
			_end_chase()
		respawn_at = Vector3(0, 3, 107)
	elif z >= 155 and z < 214:
		stage = "ПАРКУР"
		respawn_at = Vector3(0, 3, 153)
	elif z >= 214 and z < 263:
		stage = "АРЕНА"
		if not fight_on and not boss_dead:
			if telifons < 14:
				_show("Перед боссом собери 14 Телифонов! Сейчас: %d/14" % telifons, 3)
			else:
				_begin_boss()
	elif z >= 267:
		stage = "ОСТРОВ ФИНАЛА"
		if telifons == 15 and player.position.distance_to(final_cat.position) < 6:
			_finish()

func _update_pickups(delta: float) -> void:
	for item in pickups:
		if item["taken"]:
			continue
		var node: Node3D = item["node"]
		node.rotate_y(delta * 1.2)
		if player.global_position.distance_to(node.global_position) < 2.0:
			item["taken"] = true
			node.queue_free()
			telifons += 1
			_show("ТЕЛИФОН НАЙДЕН! %d/15" % telifons, 2)

func _update_enemies(delta: float) -> void:
	for item in enemies:
		if item["dead"] or ending:
			continue
		var node: Node3D = item["node"]
		var diff := player.global_position - node.global_position
		diff.y = 0
		if diff.length() < 11 and diff.length() > 1:
			node.global_position += diff.normalized() * float(item["speed"]) * delta
			node.look_at(Vector3(player.global_position.x, node.global_position.y, player.global_position.z), Vector3.UP)
		elif diff.length() >= 11:
			var back: Vector3 = item["home"] - node.global_position
			back.y = 0
			if back.length() > 0.2:
				node.global_position += back.normalized() * delta * 1.8
		if diff.length() < 1.7:
			_get_hit()

func _begin_chase() -> void:
	chase_on = true
	chase_enemy = Node3D.new()
	chase_enemy.name = "ТАИНСТВЕННЫЙ ПРЕСЛЕДОВАТЕЛЬ"
	chase_enemy.global_position = player.global_position - Vector3(0, -1.0, 12)
	add_child(chase_enemy)
	_orb(chase_enemy, Vector3.ZERO, Vector3(2.2, 2.5, 2.1), Color(0.79, 0.12, 0.2))
	for x in [-0.45, 0.45]:
		_orb(chase_enemy, Vector3(x, 0.35, -1.0), Vector3(0.3, 0.3, 0.2), Color.WHITE)
	_sign(chase_enemy, "БЕГИ!", Vector3(0, 2.3, 0), Color(1, 0.22, 0.25))
	music.play()
	_show("RUN FROM YOUR DEMONS! БЕГИ К КОНЦУ ДОРОГИ!", 5)

func _update_chase(delta: float) -> void:
	if not chase_on:
		return
	var toward := player.global_position - chase_enemy.global_position
	toward.y = 0
	if toward.length() > 0.1:
		chase_enemy.global_position += toward.normalized() * 11.1 * delta
	if toward.length() < 1.8:
		_get_hit()
		chase_enemy.global_position.z -= 6

func _end_chase() -> void:
	chase_on = false
	chase_done = true
	if is_instance_valid(chase_enemy): chase_enemy.queue_free()
	music.stop()
	_show("Тишина... погоня закончилась, будто ничего не было.", 5)

func _begin_boss() -> void:
	fight_on = true
	boss_time = 0
	boss_next_shot = 2
	boss_title.visible = true
	boss_bar.visible = true
	_show("ВОЗДУХАН: Вот мы и встретились! Но ты меня не победишь!", 6)

func _update_boss(delta: float) -> void:
	if not fight_on or boss_dead:
		return
	boss_time += delta
	var super_form := boss_hp <= 5
	var period := 6.2 if super_form else 7.6
	var phase := fmod(boss_time, period)
	boss_weak = phase >= (period - (1.55 if super_form else 2.15))
	boss.global_position.y = (1.8 if boss_weak else 5.2 + sin(boss_time * 2.5) * 0.4)
	boss_title.text = "ВОЗДУХАН — СУПЕРФОРМА!" if super_form else "ВОЗДУХАН"
	if boss_weak:
		boss_title.text += "   [БЕЙ ТАПКОМ!]"
	if boss_time >= boss_next_shot and not boss_weak:
		boss_next_shot = boss_time + (1.15 if super_form else 2.0)
		var air := Node3D.new()
		air.name = "Воздушный заряд"
		air.global_position = boss.global_position + Vector3(0, 0, -2)
		add_child(air)
		_orb(air, Vector3.ZERO, Vector3(0.72, 0.72, 0.72), Color(0.77, 0.94, 1), true)
		var dir := (player.global_position + Vector3(0, 0.8, 0) - air.global_position).normalized()
		bullets.append({"node": air, "direction": dir, "time": 6.0, "speed": 13.0 if super_form else 9.5})

func _update_bullets(delta: float) -> void:
	for b in bullets:
		if not is_instance_valid(b["node"]):
			continue
		var obj: Node3D = b["node"]
		obj.global_position += b["direction"] * float(b["speed"]) * delta
		b["time"] -= delta
		if obj.global_position.distance_to(player.global_position + Vector3(0, 1, 0)) < 1.5:
			_get_hit()
			obj.queue_free()
		elif b["time"] < 0:
			obj.queue_free()

func _win_boss() -> void:
	boss_dead = true
	fight_on = false
	boss_title.visible = false
	boss_bar.visible = false
	boss.queue_free()
	for b in bullets:
		if is_instance_valid(b["node"]): b["node"].queue_free()
	bullets.clear()
	_show("ВОЗДУХАН: Это не конец! Я вернусь!", 6)
	_create_telifon(Vector3(0, 1.5, 236), 15)
	_ground("Мост на остров финала", Vector3(0, -0.2, 265), Vector3(11, 1.0, 28), Color(0.12, 0.39, 0.34))

func _finish() -> void:
	if ending:
		return
	ending = true
	music.stop()
	credits.visible = true
	_show("КОТОСТЬ: Ты победил Воздухана! Мелстроя забрали птенцы, он в безопасности. Но у Воздухана есть секретная база... Пока это конец!", 18)
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)

func _update_hud() -> void:
	hud.text = "MEM ISLAND  |  " + "❤️".repeat(hearts) + "🖤".repeat(3-hearts) + "\nТЕЛИФОНЫ: %d / 15    |    %s\nОРУЖИЕ: %s    |    ФОНАРИК" % [telifons, stage, "ТАПОК" if got_slipper else "НЕТ"]
	if subtitle != null and text_expires > 0 and Time.get_ticks_msec() / 1000.0 > text_expires:
		subtitle.text = ""
		text_expires = 0
